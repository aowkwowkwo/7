import requests, os, time, random
from concurrent.futures import ThreadPoolExecutor

# Warna
MERAH = '\033[91m'
HIJAU = '\033[92m'
PUTIH = '\033[97m'
RESET = '\033[0m'

# User-Agent list (real & umum digunakan)
user_agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Mozilla/5.0 (X11; Linux x86_64)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)",
    "Mozilla/5.0 (Linux; Android 10; SM-A107F)",
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
    "curl/7.68.0",
    "Wget/1.20.3 (linux-gnu)"
]

# Target file yang dianggap sensitif
file_target = [
    ".env", ".env.bak", ".env.old", ".env.local", ".env.production", ".env.dev",
    "config.php~", "wp-config.php.bak", "wp-config.php.save", "wp-config.php.swp",
    "config/database.yml", "database.sql", "db.sql", "dump.sql", "backup.zip", "backup.tar.gz",
    "adminer.php", "phpinfo.php", "config.js", "config.json", "settings.py", "credentials.json",
    ".git/config", ".gitignore", ".htaccess", ".htpasswd", "web.config", "nginx.conf",
    "access.log", "error.log", "composer.lock", "package-lock.json", "id_rsa", "id_rsa.pub",
    "docker-compose.yml", "dockerfile", "api.key", "apikey.txt", "token.txt", "secret.key",
    ".bash_history", ".ssh/authorized_keys", "cloudbuild.yaml"
]

def banner():
    os.system("clear" if os.name != "nt" else "cls")
    print(f"""{MERAH}
███████╗███████╗███╗   ██╗███████╗██╗████████╗██╗██╗   ██╗███████╗
██╔════╝██╔════╝████╗  ██║██╔════╝██║╚══██╔══╝██║██║   ██║██╔════╝
███████╗█████╗  ██╔██╗ ██║███████╗██║   ██║   ██║██║   ██║█████╗
╚════██║██╔══╝  ██║╚██╗██║╚════██║██║   ██║   ██║╚██╗ ██╔╝██╔══╝
███████║███████╗██║ ╚████║███████║██║   ██║   ██║ ╚████╔╝ ███████╗
╚══════╝╚══════╝╚═╝  ╚═══╝╚══════╝╚═╝   ╚═╝   ╚═╝  ╚═══╝  ╚══════╝


███████╗██╗███╗   ██╗██████╗ ███████╗██████╗
██╔════╝██║████╗  ██║██╔══██╗██╔════╝██╔══██╗
█████╗  ██║██╔██╗ ██║██║  ██║█████╗  ██████╔╝
██╔══╝  ██║██║╚██╗██║██║  ██║██╔══╝  ██╔══██╗
██║     ██║██║ ╚████║██████╔╝███████╗██║  ██║
╚═╝     ╚═╝╚═╝  ╚═══╝╚═════╝ ╚══════╝╚═╝  ╚═╝
{PUTIH}InfernalXploit - Sensitive Finder + CF Bypass
{RESET}
""")

# Fungsi cek tiap file
def cek_file(domain):
    if not domain.startswith("http"):
        domain = "http://" + domain

    for path in file_target:
        url = domain.rstrip("/") + "/" + path
        headers = {
            "User-Agent": random.choice(user_agents),
            "Accept": "*/*",
            "Connection": "keep-alive"
        }

        try:
            r = requests.get(url, headers=headers, timeout=15, allow_redirects=True)
            content = r.text.lower()

            if r.status_code == 200:
                # Deteksi konten sensitif
                if any(keyword in content for keyword in ["db_", "api_key", "jwt", "authorization", "mysql", "token", "aws"]):
                    print(f"{HIJAU}[✓] SENSITIF: {url}{RESET}")
                    with open("HASIL_SENSITIF.txt", "a") as f:
                        f.write(url + "\n")
                elif "Index of" in content or "root:x:" in content:
                    print(f"{HIJAU}[✓] INDEX TERBUKA: {url}{RESET}")
                    with open("HASIL_SENSITIF.txt", "a") as f:
                        f.write(url + "\n")
                else:
                    print(f"{PUTIH}[•] 200 OK tapi tidak sensitif: {url}{RESET}")
            elif r.status_code == 403:
                print(f"{MERAH}[-] Diblokir (403): {url}{RESET}")
            elif r.status_code == 503:
                print(f"{MERAH}[-] CAPTCHA/Cloudflare Block: {url}{RESET}")
            else:
                print(f"{MERAH}[X] Tidak ditemukan: {url} ({r.status_code}){RESET}")

        except Exception as e:
            print(f"{MERAH}[!] Error: {url} => {e}{RESET}")

# Start
def mulai():
    pilih = input(f"{PUTIH}[1] Scan 1 domain\n[2] Scan dari file list\n{HIJAU}>>> Pilih: {RESET}")
    
    if pilih == "1":
        target = input(f"{PUTIH}[?] Masukkan domain/IP: {RESET}").strip()
        cek_file(target)
    elif pilih == "2":
        filelist = input(f"{PUTIH}[?] Masukkan nama file list domain: {RESET}")
        try:
            with open(filelist, "r") as f:
                domain_list = [x.strip() for x in f if x.strip()]
            with ThreadPoolExecutor(max_workers=20) as exe:
                exe.map(cek_file, domain_list)
        except FileNotFoundError:
            print(f"{MERAH}[X] File tidak ditemukan.{RESET}")
    else:
        print(f"{MERAH}[X] Pilihan tidak valid.{RESET}")

if __name__ == "__main__":
    requests.packages.urllib3.disable_warnings()
    banner()
    mulai()
