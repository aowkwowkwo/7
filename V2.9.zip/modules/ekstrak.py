import os
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from colorama import Fore, Style, init
from collections import deque
from datetime import datetime

init(autoreset=True)

# Ekstensi file yang ingin difilter (bisa diubah sesuai kebutuhan)
FILTERED_EXTENSIONS = [".pdf", ".jpg", ".png", ".zip", ".exe"]

def banner():
    """Menampilkan banner program."""
    os.system('clear' if os.name == 'posix' else 'cls')

    print(Fore.RED + "███████╗██╗  ██╗████████╗██████╗  █████╗ ██╗  ██╗███████╗")
    print(Fore.RED + "██╔════╝╚██╗██╔╝╚══██╔══╝██╔══██╗██╔══██╗██║ ██╔╝██╔════╝")
    print(Fore.RED + "█████╗   ╚███╔╝    ██║   ██████╔╝███████║█████╔╝ ███████╗")
    print(Fore.RED + "██╔══╝   ██╔██╗    ██║   ██╔══██╗██╔══██║██╔═██╗ ╚════██║")
    print(Fore.RED + "███████╗██╔╝ ██╗   ██║   ██║  ██║██║  ██║██║  ██╗███████║")
    print(Fore.RED + "╚══════╝╚═╝  ╚═╝   ╚═╝   ╚═╝       ╚══════╝")
    print(Fore.YELLOW + "FULL WEBSITE LINK EXTRACTOR BY INFERNALXPLOIT")
    print(Fore.YELLOW + "FULL WEBSITE LINK EXTRACTOR BY InfernalXploit")

def check_time_limit():
    """Memeriksa apakah program masih dalam masa penggunaan."""
    start_date = datetime(2024, 12, 1)
    end_date = datetime(2026, 1, 7)
    current_date = datetime.now()
    if current_date < start_date or current_date > end_date:
        print(Fore.RED + "[ERROR] Masa penggunaan program telah habis.")
        exit()

def extract_links(url):
    """Mengekstrak semua tautan dari URL yang diberikan."""
    try:
        response = requests.get(url)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, 'html.parser')
        links = set()

        for a_tag in soup.find_all('a', href=True):
            href = urljoin(url, a_tag['href'])  # Mengonversi tautan relatif ke absolut
            links.add(href)

        return links

    except requests.exceptions.RequestException as e:
        print(Fore.RED + f"[!] Kesalahan saat mengakses {url}: {e}")
        return set()

def is_broken_link(url):
    """Memeriksa apakah suatu tautan mati atau tidak."""
    try:
        response = requests.head(url, allow_redirects=True, timeout=5)
        return response.status_code >= 400
    except requests.exceptions.RequestException:
        return True

def crawl_website(start_url, filter_extension=False, check_broken=False):
    """Melakukan crawling website untuk mengekstrak semua tautan."""
    visited = set()
    to_visit = deque([start_url])  # Antrian halaman untuk dikunjungi
    all_links = set()
    broken_links = set()
    filtered_links = set()

    while to_visit:
        current_url = to_visit.popleft()

        if current_url in visited:
            continue

        print(Fore.CYAN + f"\n[+] Mengunjungi: {Fore.GREEN}{current_url}")
        visited.add(current_url)

        links = extract_links(current_url)
        all_links.update(links)

        base_domain = urlparse(start_url).netloc
        for link in links:
            if base_domain in urlparse(link).netloc and link not in visited:
                to_visit.append(link)

            # Cek tautan mati jika diaktifkan
            if check_broken and is_broken_link(link):
                broken_links.add(link)

            # Filter tautan berdasarkan jenis file
            if filter_extension and any(link.endswith(ext) for ext in FILTERED_EXTENSIONS):
                filtered_links.add(link)

    return all_links, broken_links, filtered_links

def save_links_to_file(links, filename):
    """Menyimpan tautan ke file."""
    try:
        with open(filename, 'w') as file:
            for link in links:
                file.write(link + "\n")
        print(Fore.GREEN + f"\n[+] Semua tautan berhasil disimpan di: {Fore.YELLOW}{filename}")
    except Exception as e:
        print(Fore.RED + f"[!] Gagal menyimpan tautan: {e}")

def main():
    """Fungsi utama program."""
    check_time_limit()
    banner()
    url = input(Fore.RED + "MASUKAN URL: ").strip()

    if not url.startswith("http"):
        url = "https://" + url

    # Pilihan fitur tambahan
    filter_option = input(Fore.YELLOW + "[?] Hanya ambil tautan file tertentu? (y/n): ").strip().lower() == 'y'
    check_broken_option = input(Fore.YELLOW + "[?] Periksa tautan mati? (y/n): ").strip().lower() == 'y'

    print(Fore.CYAN + f"\n[+] Memulai proses crawling pada: {Fore.GREEN}{url}")
    all_links, broken_links, filtered_links = crawl_website(url, filter_option, check_broken_option)

    if all_links:
        print(Fore.CYAN + f"\n[+] Total tautan ditemukan: {Fore.GREEN}{len(all_links)}")
        for link in all_links:
            print(Fore.GREEN + f"[+] {link}")

        save_option = input(Fore.YELLOW + "\n[?] Simpan tautan ke file? (y/n): ").strip().lower()
        if save_option == 'y':
            filename = input(Fore.YELLOW + "Masukkan nama file (contoh: all_links.txt): ").strip()
            save_links_to_file(all_links, filename)

    if filtered_links:
        print(Fore.CYAN + f"\n[+] Tautan dengan ekstensi yang difilter ditemukan: {Fore.GREEN}{len(filtered_links)}")
        for link in filtered_links:
            print(Fore.GREEN + f"[Filtered] {link}")

        save_filtered = input(Fore.YELLOW + "\n[?] Simpan tautan file tertentu ke file? (y/n): ").strip().lower()
        if save_filtered == 'y':
            filename_filtered = input(Fore.YELLOW + "Masukkan nama file (contoh: filtered_links.txt): ").strip()
            save_links_to_file(filtered_links, filename_filtered)

    if broken_links:
        print(Fore.RED + f"\n[!] Total tautan mati ditemukan: {len(broken_links)}")
        for link in broken_links:
            print(Fore.RED + f"[Broken] {link}")

        save_broken = input(Fore.YELLOW + "\n[?] Simpan tautan mati ke file? (y/n): ").strip().lower()
        if save_broken == 'y':
            filename_broken = input(Fore.YELLOW + "Masukkan nama file (contoh: broken_links.txt): ").strip()
            save_links_to_file(broken_links, filename_broken)

    else:
        print(Fore.RED + "[!] Tidak ada tautan ditemukan atau situs tidak dapat diakses.")

if __name__ == "__main__":
    main()
