import requests
import random
import os

# Warna ANSI
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
RESET = "\033[0m"

# Banner
def banner():
    print(f"""{RED}
    ██████████████████████████████
    █─▄▄▄▄█─▄▄─█▄─▄███▄─█─▄█▄─▄▄─█
    █▄▄▄▄─█─██─██─██▀██▄─▄███─▄█▀█
    ▀▄▄▄▄▀▄▄▄▄▀▄▄▄▄▄▀▀▄▄▄▀▀▄▄▄▄▄▀{RESET}
    {CYAN}InfernalXploit Email Reporter by Proxy{RESET}
    """)

# Clear layar
def clear_screen():
    os.system("clear" if os.name == "posix" else "cls")

# Load proxy dari file (format: proxy:port)
def load_proxies():
    try:
        with open("proxy.txt", "r") as file:
            return [line.strip() for line in file.readlines() if line.strip()]
    except FileNotFoundError:
        print(f"{RED}[x] File proxy.txt tidak ditemukan!{RESET}")
        return []

# Fungsi lapor email via proxy
def report_email(email, jumlah, proxies):
    report_url = "https://outlook.live.com/mail/0/"  # Target server email (ganti sesuai kebutuhan)
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
    data = {"email": email, "report_reason": "spam"}

    session = requests.Session()

    for i in range(jumlah):
        if not proxies:
            print(f"{RED}[x] Tidak ada proxy tersedia!{RESET}")
            break
        
        proxy = random.choice(proxies)
        proxy_dict = {"http": f"http://{proxy}", "https": f"http://{proxy}"}

        try:
            response = session.post(report_url, headers=headers, data=data, proxies=proxy_dict, timeout=10)
            if response.status_code in [200, 201, 202, 204]:
                print(f"{GREEN}[{i+1}/{jumlah}] Berhasil lapor {email} via {proxy}{RESET}")
            else:
                print(f"{YELLOW}[{i+1}/{jumlah}] Gagal lapor {email}. Status: {response.status_code}{RESET}")
        except requests.exceptions.RequestException:
            print(f"{RED}[{i+1}/{jumlah}] Proxy Error! {proxy} mati atau gagal koneksi.{RESET}")

# Program utama
while True:
    clear_screen()
    banner()
    print(f"{CYAN}===== MENU ====={RESET}")
    print(f"{GREEN}[1]{RESET} Laporkan Email")
    print(f"{GREEN}[2]{RESET} Keluar")
    
    pilihan = input(f"{CYAN}Pilih opsi:{RESET} ")

    if pilihan == "1":
        target_email = input(f"{CYAN}Masukkan email target: {RESET}")
        jumlah_report = int(input(f"{CYAN}Masukkan jumlah report: {RESET}"))
        proxy_list = load_proxies()
        report_email(target_email, jumlah_report, proxy_list)
    elif pilihan == "2":
        print(f"{RED}Keluar dari program.{RESET}")
        break
    else:
        print(f"{RED}[x] Pilihan tidak valid!{RESET}")
