import marshal
import base64
import zlib
import os
os.system('clear')
def encrypt(file_path, author_name):
    if not os.path.exists(file_path):
        print(f"[!] File {file_path} tidak ditemukan.")
        return

    with open(file_path, 'r', encoding='utf-8') as file:
        source_code = file.read()

    # Compile source ke bytecode
    compiled_code = compile(source_code, '<string>', 'exec')
    marshaled_code = marshal.dumps(compiled_code)
    compressed_code = zlib.compress(marshaled_code)
    encoded_code = base64.b64encode(compressed_code).decode('utf-8')

    # Membuat isi file terenkripsi
    output = f'''# Encrypted by: {author_name}

import marshal
import zlib
import base64

exec(marshal.loads(zlib.decompress(base64.b64decode("{encoded_code}"))))
'''

    # Membuat file output
    output_file = file_path.replace('.py', '_enc.py')

    with open(output_file, 'w', encoding='utf-8') as file:
        file.write(output)

    print(f"[✓] File terenkripsi sukses: {output_file}")

if __name__ == '__main__':
    print("=== Python File Encryptor ===")
    print("By InfernalXploit")
    print("-" * 30)
    target_file = input("Masukkan nama file .py yang mau dienkripsi: ").strip()
    author = input("Masukkan nama kamu untuk dicantumkan: ").strip()
    encrypt(target_file, author)
