from colorama import Fore, init
import os

# Inisialisasi colorama
init(autoreset=True)
os.system('clear')

def banner():
    print(f"""{Fore.CYAN}
██╗███╗   ██╗███████╗███████╗██████╗ ███╗   ██╗ █████╗ ██╗     
██║████╗  ██║██╔════╝██╔════╝██╔══██╗████╗  ██║██╔══██╗██║     
██║██╔██╗ ██║█████╗  █████╗  ██████╔╝██╔██╗ ██║███████║██║     
██║██║╚██╗██║██╔══╝  ██╔══╝  ██╔═══╝ ██║╚██╗██║██╔══██║██║     
██║██║ ╚████║███████╗███████╗██║     ██║ ╚████║██║  ██║███████╗
╚═╝╚═╝  ╚═══╝╚══════╝╚══════╝╚═╝     ╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝
{Fore.YELLOW}          Created by InfernalXploit | IG: @infernalxploit
{Fore.GREEN} - Memfilter domain yang mengandung:
   * wp-login.php -> Logs_Wordpress.txt
   * 2083        -> Logs_cPanel.txt
   * 2087        -> Logs_Whm.txt
   * 2096        -> Logs_Webmail.txt
   * 587         -> Logs_Smtp.txt
 - Format: url|user|pass
""" + Fore.YELLOW + "="*60)

def filter_file(input_file):
    output_files = {
        "wp-login.php": "Logs_Wordpress.txt",
        "2083": "Logs_cPanel.txt",
        "2087": "Logs_Whm.txt",
        "2096": "Logs_Webmail.txt",
        "587": "Logs_Smtp.txt"
    }

    def load_existing(file_name):
        try:
            with open(file_name, 'r', encoding='utf-8', errors='ignore') as f:
                return set(x.strip() for x in f)
        except:
            return set()

    existing = {k: load_existing(v) for k, v in output_files.items()}
    handles = {k: open(v, "a", encoding='utf-8') for k, v in output_files.items()}
    count = {k: 0 for k in output_files}

    try:
        with open(input_file, 'r', encoding='utf-8', errors='ignore') as file:
            print(Fore.CYAN + f"\n📂 Memproses file: {input_file}")
            for line in file:
                line = line.strip()
                if not line: continue

                for marker in output_files:
                    if marker in line and line.count(":") >= 2:
                        try:
                            before, after = line.split(f"{marker}:", 1)
                            url = before.strip() + marker
                            user, passwd = after.split(":", 1)
                            final = f"{url}|{user.strip()}|{passwd.strip()}"

                            if final not in existing[marker]:
                                handles[marker].write(final + "\n")
                                existing[marker].add(final)
                                count[marker] += 1
                                print(Fore.GREEN + f"✅ [{marker}] {final}")
                        except:
                            continue

        print(Fore.CYAN + "\n🔍 Ringkasan:")
        for k in output_files:
            print(Fore.GREEN + f"  - {k}: {count[k]} ditemukan")

        # Hapus file input
        os.remove(input_file)
        print(Fore.YELLOW + f"\n🗑️ File input '{input_file}' berhasil dihapus.")

    except FileNotFoundError:
        print(Fore.RED + f"❌ File '{input_file}' tidak ditemukan.")
    except Exception as e:
        print(Fore.RED + f"❌ Error: {e}")
    finally:
        for f in handles.values():
            f.close()

# Program utama
if __name__ == "__main__":
    banner()
    nama_file = input(Fore.CYAN + "\n📥 Masukkan nama file yang ingin difilter (cth: mylist.txt): ").strip()
    filter_file(nama_file)
