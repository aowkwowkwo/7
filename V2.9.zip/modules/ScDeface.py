import os

def clear(): os.system('clear' if os.name == 'posix' else 'cls')

clear() 
print("=== InfernalXploit Deface Page Generator ===\n")

# Input dari pengguna
nama = input("Masukkan nama defacer (ex: InfernalXploit): ")
logo = input("Masukkan link logo: ")
lagu = input("Masukkan link lagu (mp3): ")
thanks = input("Masukkan kata-kata thanks: ")
gretzz = input("Masukkan kata-kata gretzz: ")
narasi1 = input("Masukkan narasi 1 (atas): ")
narasi2 = input("Masukkan narasi 2 (bawah): ")
subtitle = input("Masukkan subtitle (pesan di bawah judul): ")  # Input baru untuk subtitle

# Struktur HTML
html = f"""<!DOCTYPE html>

<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HACKED BY {nama.upper()}</title>
    <link href="https://fonts.googleapis.com/css2?family=Iceland&display=swap" rel="stylesheet">
    <style>
        body {{
            background-color: black;
            color: white;
            text-align: center;
            font-family: 'Iceland', sans-serif;
            margin: 0;
            padding: 0;
        }}
        .title {{
            font-size: 3em;
            color: red;
            margin-top: 30px;
        }}
        .logo img {{
            width: 250px;
            height: 250px;
            margin-top: 50px;
            object-fit: cover;
            border: solid 2px red;
            padding: 10px;
            box-shadow: 0 0 20px red;
        }}
        .subtitle {{
            font-size: 1.5em;
            color: #0ff;
            margin: 20px 0;
        }}
        .content {{
            font-size: 1.2em;
            margin: 20px 30px;
        }}
        .footer {{
            margin-top: 30px;
            font-size: 0.9em;
            color: gray;
        }}
        .thanks, .gretz {{
            margin-top: 40px;
            font-size: 0.9em;
            color: #aaa;
            white-space: pre-wrap;
            padding: 0 20px;
        }}
        audio {{
            margin-top: 30px;
        }}
    </style>
</head>
<body>
    <h1 class="title">HACKED BY {nama.upper()}</h1>
    <div class="logo">
        <img src="{logo}" alt="{nama} Logo">
    </div>

    <h2 class="subtitle">{subtitle}</h2>  <!-- Subtitle yang bisa diubah -->

    <div class="content">
        This site has been hacked by <strong style="color:red;">{nama}</strong><br><br>
        <span style="color:lime;">
            {narasi1}<br><br>
            {narasi2}
        </span>
    </div>

    <audio src="{lagu}" loop autoplay controls></audio>

    <div class="thanks"><strong>THANKS TO:</strong><br>{thanks}</div>
    <div class="gretz"><strong>GRETZ TO:</strong><br>{gretzz}</div>

    <div class="footer">&copy; 2025 {nama}. All Rights Destroyed.</div>

</body>
</html>
"""

# Simpan file
with open("deface.html", "w", encoding="utf-8") as f:
    f.write(html)

print("\n[✓] File berhasil dibuat: deface.html")
