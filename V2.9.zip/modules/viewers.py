import os

def buka_situs(url):
    os.system(f"xdg-open {url}")

if __name__ == "__main__":
    url = "https://zefoy.com"  # Ganti dengan situs yang ingin dibuka
    buka_situs(url)
