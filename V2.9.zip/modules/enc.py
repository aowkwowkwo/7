from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import base64
import os

TOSCA = '\033[96m'
RESET = '\033[0m'

comment_map = {
    ".py": "#",
    ".sh": "#",
    ".php": "//",
    ".js": "//"
}

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    print(f"""{TOSCA}
    ╔═╗┬┌─┐┬  ┌─┐┬┌┬┐  ╔═╗┬═┐┌─┐┬ ┬
    ║  │├─┤│  ├─┤│ │   ╠═╝├┬┘├─┤│││
    ╚═╝┴┴ ┴┴─┘┴ ┴┴ ┴   ╩  ┴└─┴ ┴└┴┘
    Silent RepAEr v2.1 by InfernalXploit{RESET}
""")

def get_comment_style(filename):
    _, ext = os.path.splitext(filename)
    return comment_map.get(ext.lower(), "#")

def encode_file(filepath, key):
    if not os.path.isfile(filepath):
        print(f"{TOSCA}[!] File tidak ditemukan.{RESET}")
        return

    cipher = AES.new(key.encode(), AES.MODE_CBC)
    
    with open(filepath, "rb") as f:
        raw = f.read()

    encrypted = cipher.encrypt(pad(raw, AES.block_size))
    encrypted_base64 = base64.b64encode(cipher.iv + encrypted).decode()

    comment = get_comment_style(filepath)

    result = f"{comment}-- Encrypted by InfernalXploit --\n{encrypted_base64}\n{comment}-- End Encrypted --"

    with open(filepath, "w") as f:
        f.write(result)

    print(f"{TOSCA}[+] File berhasil terenkripsi: {filepath}{RESET}")

def decode_file(filepath, key):
    if not os.path.isfile(filepath):
        print(f"{TOSCA}[!] File tidak ditemukan.{RESET}")
        return

    with open(filepath, "r") as f:
        lines = f.readlines()

    comment = get_comment_style(filepath)
    start_tag = f"{comment}-- Encrypted by InfernalXploit --\n"
    end_tag = f"{comment}-- End Encrypted --"

    try:
        start = lines.index(start_tag) + 1
        end = lines.index(end_tag + "\n") if (end_tag + "\n") in lines else lines.index(end_tag)
        encrypted_data = ''.join(lines[start:end])

        encrypted = base64.b64decode(encrypted_data)
        iv = encrypted[:16]  # Extract the IV
        encrypted = encrypted[16:]  # The actual encrypted content

        cipher = AES.new(key.encode(), AES.MODE_CBC, iv)
        decrypted = unpad(cipher.decrypt(encrypted), AES.block_size)

        with open(filepath, "wb") as f:
            f.write(decrypted)

        print(f"{TOSCA}[+] File berhasil didekripsi: {filepath}{RESET}")
    except Exception as e:
        print(f"{TOSCA}[!] Gagal dekripsi: {e}{RESET}")

def get_path(ext):
    path = input(f"{TOSCA}Path file (*.{ext}): {RESET}").strip()
    return path if os.path.isfile(path) else None

def get_key():
    key = input(f"{TOSCA}Masukkan kunci (16 karakter): {RESET}").strip()
    if len(key) != 16:
        print(f"{TOSCA}[!] Kunci harus 16 karakter!{RESET}")
        return None
    return key

def menu():
    while True:
        clear()
        banner()
        print(f"""{TOSCA}
[1] Enkripsi JavaScript (.js)
[2] Enkripsi PHP (.php)
[3] Enkripsi Bash (.sh)
[4] Enkripsi Python (.py)
[5] Dekripsi JavaScript (.js)
[6] Dekripsi PHP (.php)
[7] Dekripsi Python (.py)
[8] Dekripsi Bash (.sh)
[9] Keluar
{RESET}""")
        pilihan = input(f"{TOSCA}Pilih menu (1–9): {RESET}").strip()

        match pilihan:
            case "1":
                path = get_path("js")
                if path:
                    key = get_key()
                    if key:
                        encode_file(path, key)
            case "2":
                path = get_path("php")
                if path:
                    key = get_key()
                    if key:
                        encode_file(path, key)
            case "3":
                path = get_path("sh")
                if path:
                    key = get_key()
                    if key:
                        encode_file(path, key)
            case "4":
                path = get_path("py")
                if path:
                    key = get_key()
                    if key:
                        encode_file(path, key)
            case "5":
                path = get_path("js")
                if path:
                    key = get_key()
                    if key:
                        decode_file(path, key)
            case "6":
                path = get_path("php")
                if path:
                    key = get_key()
                    if key:
                        decode_file(path, key)
            case "7":
                path = get_path("py")
                if path:
                    key = get_key()
                    if key:
                        decode_file(path, key)
            case "8":
                path = get_path("sh")
                if path:
                    key = get_key()
                    if key:
                        decode_file(path, key)
            case "9":
                print(f"{TOSCA}Keluar dari program...{RESET}")
                break
            case _:
                print(f"{TOSCA}Pilihan tidak valid.{RESET}")
        input(f"{TOSCA}Tekan Enter untuk lanjut...{RESET}")

if __name__ == "__main__":
    menu()
