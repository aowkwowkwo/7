import requests as r, random, json, os, sys
from time import sleep

# Warna
R = '\033[91m'  # Merah
G = '\033[92m'  # Hijau Tosca
W = '\033[97m'  # Putih
C = '\033[96m'  # Cyan
reset = '\033[0m'

list_mail = ["vintomaper.com", "tovinit.com", "mentonit.net"]
url = "https://cryptogmail.com/"
num = 0

def get_teks(accept, key):
    cek = r.get(url + "api/emails/" + key, headers={"accept": accept}).text
    if "error" in cek:
        return "-"
    else:
        return cek.strip()

def get_random(digit):
    lis = list("abcdefghijklmnopqrstuvwxyz0123456789")
    dig = [random.choice(lis) for _ in range(digit)]
    return "".join(dig), random.choice(list_mail)

def animate(teks):
    lis = list("\|/-")
    for cy in lis:
        print(f"\r{C}[{cy}] {teks}..{reset} ", end="")
        sleep(0.3)

def run(email):
    while True:
        try:
            animate("Menunggu pesan masuk")
            raun = r.get(url + "api/emails?inbox=" + email).text
            if "404" in raun:
                continue
            elif "data" in raun:
                z = json.loads(raun)
                for data in z["data"]:
                    print(f"\n{W}[•] ID: {data['id']}{reset}")
                    got = json.loads(r.get(url + "api/emails/" + data["id"]).text)
                    pengirim = got["data"]["sender"]["display_name"]
                    email_pe = got["data"]["sender"]["email"]
                    subject = got["data"]["subject"]
                    print(f"{G}[•] Nama Pengirim : {pengirim}{reset}")
                    print(f"{G}[•] Email Pengirim: {email_pe}{reset}")
                    print(f"{G}[•] Subjek        : {subject}{reset}")
                    print(f"{G}[•] Pesan         : {get_teks('text/html,text/plain', data['id'])}{reset}")
                    atc = got["data"]["attachments"]
                    if atc == []:
                        print(f"{G}[•] Lampiran      : -{reset}")
                    else:
                        print(f"{G}[•] Lampiran:{reset}")
                        for atch in atc:
                            id = atch["id"]
                            name = atch["file_name"]
                            ext = name.split(".")[-1]
                            sv = r.get(f"https://cryptogmail.com/api/emails/{data['id']}/attachments/{id}")
                            open(id + "." + ext, "wb").write(sv.content)
                            print(f"      {W}~ {id}.{ext}{reset}")
                    print(f"{C}" + "-" * 45 + f"{reset}")
                    r.delete(url + "api/emails/" + data["id"])
                continue
            else:
                continue
        except (KeyboardInterrupt, EOFError):
            exit(f"\n{W}[✓] Program dihentikan, keluar...{reset}\n")

def main():
    os.system("clear")
    global num
    print(f"""{C}
╔═════════════════════════════════════════════════════════╗
║            {W}INFERNALXploit TEMP MAIL TERMINAL{C}            ║
╚═════════════════════════════════════════════════════════╝{reset}
{R}[01]{reset} {W}EMAIL RANDOM
{R}[02]{reset} {W}EMAIL CUSTOM
{R}[00]{reset} {W}KELUAR{reset}
""")
    pil = input(f"{G}[?] Pilih menu: {reset}")
    while pil == "" or not pil.isdigit():
        pil = input(f"{G}[?] Pilih menu: {reset}")
    if pil in ["01", "1"]:
        set_name, set_email = get_random(10)
        print(f"\n{W}[*] Email kamu: {set_name}@{set_email}{reset}")
        print(f"{G}[*] Tekan CTRL + C untuk keluar{reset}")
        print(f"{C}" + "-" * 45 + f"{reset}")
        run(set_name + "@" + set_email)
    elif pil in ["02", "2"]:
        set_name = input(f"{G}[•] Nama email: {reset}")
        print()
        for i, cy in enumerate(list_mail, 1):
            print(" " * 5, f"[{i}] @{cy}")
        print()
        set_email = input(f"{W}[?] Pilih domain (angka): {reset}")
        while set_email == "" or not set_email.isdigit() or int(set_email) > len(list_mail):
            set_email = input(f"{W}[?] Pilih domain (angka): {reset}")
        mail = list_mail[int(set_email) - 1]
        print(f"\n{W}[*] Email kamu: {set_name}@{mail}{reset}")
        print(f"{G}[*] Tekan CTRL + C untuk keluar{reset}")
        print(f"{C}" + "-" * 45 + f"{reset}")
        run(set_name + "@" + mail)
    elif pil in ["00", "0"]:
        exit(f"{W}[=] Keluar program...{reset}")
    else:
        exit(f"{R}[-] Menu tidak ditemukan, keluar...{reset}")

if __name__ == "__main__":
    main()
